## Supported platforms

- Development platform: macOS arm64
- Supported runtime platforms: macOS arm64, macOS amd64, Linux amd64, Linux arm64
- Required build feature: CGO
- Linux verification: required in CI
- Windows: unsupported in PR-04

## TDLib

- Interface: modern JSON C API
- Binding: internal dynamic cgo wrapper (`internal/telegram/tdjson`)
- Pinned repository: https://github.com/tdlib/td
- Pinned commit: `<PINNED_SHA>`
- Expected TDLib version: `<VERSION>`
- Build method: source CMake, shared `tdjson` target
- Native entry points: `td_create_client_id`, `td_send`, `td_receive`, `td_execute`
- Runtime library discovery: `TELECLI_TDLIB_LIBRARY`, then configuration, then repository development path, then system loader default
- Runtime version source: synchronous `getOption("version")`
- Runtime commit source: synchronous `getOption("commit_hash")`
- Compatibility manifest: `internal/telegram/compatibility.go`
- Receive ownership: exactly one process-wide `td_receive` loop
- Unsupported in PR-04: authorization, chats, messages, sending user messages, logout, verified database flush
