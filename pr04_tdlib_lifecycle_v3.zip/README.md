# PR-04 TDLib lifecycle source bundle

Copy the files into the repository rooted at module `telecli`, then replace the corresponding sections in `PROJECT_FACTS.md` with `PROJECT_FACTS.tdlib.md`.

The bundle intentionally leaves `<PINNED_SHA>` and `<VERSION>` unresolved. Do not mark compatibility as verified until both values are obtained from the built runtime.

Run:

```bash
gofmt -w internal/telegram
go test ./internal/telegram/... -count=1
go test -race ./internal/telegram/... -count=1
go vet ./internal/telegram/...
```

The cgo package compiles without linking to TDLib because it loads the shared library dynamically. Runtime integration still requires `libtdjson.dylib` on macOS or `libtdjson.so` on Linux.
