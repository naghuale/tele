# ADR-0001: TDLib modern JSON C API through an internal dynamic cgo loader

## Status
Accepted

## Context
telecli supports macOS and Linux and needs a pinned, auditable TDLib integration without adopting a third-party Go wrapper lifecycle.

## Decision
Use an internal cgo dynamic loader for the modern TDLib JSON C API:

- `td_create_client_id`
- `td_send`
- `td_receive`
- `td_execute`

The loader uses `dlopen`/`dlsym` on macOS and Linux. telecli owns exactly one process-wide `td_receive` loop and routes each JSON object by `@client_id` to a logical client. Requests are correlated later through `@extra`.

## Supported platforms
- macOS arm64 and amd64
- Linux amd64 and arm64
- CGO is required for native TDLib integration

## Compatibility
Runtime version and commit are obtained synchronously through `td_execute` with `getOption("version")` and `getOption("commit_hash")`. A runtime is verified only when it matches the pinned manifest.

## Consequences
- No logical client may call `td_receive` directly.
- The runtime must stop its receive loop before unloading `libtdjson`.
- PR-04 does not claim logout, database flush, or `authorizationStateClosed` semantics.
- Linux integration must be verified in Linux CI.
